# White-Label Branding Integration Pattern

<!-- authority: contract -->
<!-- verified: 2026-09-05 -->
<!-- overrides: none -->

Shared reference for Parallax skills that render visual content (markdown reports, .docx letters) and need to swap the default Parallax-CG palette for a client's brand when configured.

JIT-loaded by consumer skills via the sentinel comment `<!-- white-label: integration-pattern.md -->` placed at the top of each consuming `SKILL.md` and a `Load .../integration-pattern.md` directive at the call site (the `### Pre-Render — Load white-label branding` step). The pairing is asserted by `tests/test_integration_pattern_referenced.py`.

This file is **specification**, not Python. The consumer SKILL.md is the operator instruction; this doc supplies the contract and patterns the operator follows.

---

## §1 — Purpose & scope

**In scope:** visual identity for rendered output — palette tokens, fonts, cover-page or header logo, client name in the deliverable header, and a one-line Branding row in the About This Report footer.

**Out of scope:**

- **Voice prose generation.** Brand tone, persona, signature phrases. Voice is a separate concern handled by future writing-pipeline skills (newsletter, letter, content marketing). Visual-rendering skills MUST NOT generate prose from `branding["voice"]`.
- **Auto-jurisdiction disclaimers.** Disclaimers stay as the standard wording per each skill's own Disclaimer section. Voice config does not override the disclaimer block.
- **Semantic color overrides.** Tokens `cg-green-700` (positive), `cg-red-700` (negative), `cg-amber-*` (warning) signal meaning, not brand identity. They are NEVER overridden by client branding.

The structural guardrail enforcing this scope is `load_visual_branding()` in `loader.py` — it returns only the seven visual keys; voice and v2 token-tree fields are absent from the dict, so accidental access raises `KeyError`.

---

## §2 — Loading the branding

Every consumer skill loads branding with one `run-shell` call of exactly this line, with `<skill-dir>` written as the calling skill's literal directory (conventions §14: no variables, no `cd`, no inline `python3 -c` code):

```
python3 "<skill-dir>/_vendored/_parallax/white-label/loader.py" --json
```

It prints one JSON object: `colors` (hex values only), `fonts` (plain names only), `logos` (the absolute local path the loader resolved, or empty), `render` (only `audience_default`), each keeping only the entries of that shape (§3); `client_name`, already made inert markdown text; `error`, reduced to its class (§4: `config_not_found`, `schema_invalid`, `yaml_parse_error`, `yaml_read_error`, `schema_unavailable`, `logo_missing`, `schema_unavailable; logo_missing`, or `config_error`); `white_label_active` (an active loader state plus at least one displayable client name, color, font or logo after filtering); and `source_reference` (from `safe_source_reference()`, §7). The raw `source` and raw error detail are not printed, because both can carry config content. Use `white_label_active` and `source_reference` as given; never recompute them.

RM markdown consumers use `rm_consumer.py` instead, which renders the header and About This Report lines for them:

```
python3 "<skill-dir>/_vendored/_parallax/white-label/rm_consumer.py" --label "<deliverable label>" --audience <flag>
```

`--audience` takes only a fixed value, never the user's text: write `--audience client_safe` or `--audience internal_analyst` when the invocation's `audience=` value is exactly one of those, write `--audience unrecognized` for any other non-empty value (the command then adds the unrecognized-value notice), and leave `--audience` out when no `audience=` flag was given. It prints `header_lines`, `about_lines` and `resolved_audience`; place the lines in the locations defined by §5 and §7. The command calls `load_rm_branding_context()`, which calls `load_visual_branding()` internally. It centralizes source redaction, voice isolation, and default-brand fallback for client-review and desk-call-list. A skill that does not use the RM seam but needs the §13.1 audience mode runs `python3 "<skill-dir>/_vendored/_parallax/white-label/rm_consumer.py" --resolve-audience --audience <flag>` (same `--audience` rule), which prints `mode` and `notice`.

If the command runs and fails, render default Parallax branding with `Branding: default Parallax (config error)` (§7), and use audience mode `client_safe` or `internal_analyst` only when the `audience=` value is exactly that, else `internal_analyst`. If the host has no shell, do not read `config.yaml` yourself (that bypasses every check above): render default Parallax branding with `Branding: default Parallax (not loaded: no shell)` (§7), with the same audience rule. `parallax-conventions.md` §14.3 `read-config` (no state directory, no branding) covers hosts that have no state directory at all. Python callers (tests, other helpers) import the same functions: `load_visual_branding`, `is_white_label_active` and `safe_source_reference` from `loader.py`, `load_rm_branding_context` and `resolve_audience` from `rm_consumer.py`.

`white_label_active` is the rendering flag. Empty logo slots, source references and render defaults alone do not activate branding. `visual_branding_summary()` checks the filtered output as well as `is_white_label_active()`. The decision is centralized in `loader.py` — do NOT re-implement it inline (the `schema_unavailable` branch is easy to miss; see §4 and §8). `client_name` is safe to read with `.get(..., "")` because legacy configs predating the field return `""` rather than `KeyError`.

**Do not load the YAML directly.** A second `yaml.safe_load` against the same config file bypasses the loader's error handling, schema validation, and logo resolution, and creates a race window between the loader's existence check and the second read.

---

## §3 — Safe key access

`load_visual_branding()` returns exactly seven keys: `client_name`, `colors`, `logos`, `fonts`, `source`, `error`, `render`. (The §2 command prints a display-safe form of these: no `source`, and `source_reference` and `white_label_active` added.) `render` carries deployment render defaults; audience semantics live in `parallax-conventions.md` §13 and this doc only carries the key. Voice and v2-only token-tree fields (`typography`, `rounded`, `spacing`, `components`, `multi_source`, `confidence_scores`) are absent.

The §2 JSON command preserves invalid audience-default categories so the §13.1 fallback notice still applies when schema validation is unavailable. Recognized `render.audience_default` values pass through unchanged. Unknown strings become the fixed string `unrecognized`; malformed render blocks or non-string defaults become `{"audience_default": false}`. Missing or null defaults produce `{}` silently. These fixed values carry no raw configuration text. Apply the per-invocation audience flag first, as §13.1 requires.

This is enforced by the loader at code level (a dict-comprehension over the `_VISUAL_BRANDING_KEYS` constant in `loader.py`). Accidental `branding["voice"]` access raises `KeyError`. **The constant in `loader.py` is the machine-enforced source of truth; the seven-key list above is its human-readable declaration. If the two ever diverge during a PR, the constant wins — and `tests/test_loader.py::test_visual_branding_keys_are_subset_of_load_client_branding` will fail.** Update both together (see §9).

If a future visual key (e.g. `branding["icons"]`) is added, the allowlist must be updated deliberately — additive-safe by construction.

---

## §4 — Error handling

`branding["error"]` (in the §2 command's output, its class only) is one of the values below. In Python, the loader's raw string carries detail after the class; never put that detail in a deliverable, because parse and schema messages can quote config content.

| Value | Meaning | What the skill does |
|---|---|---|
| `None` | Clean load | Apply white-label substitution. |
| `"config_not_found"` | No client onboarded | Silent default-Parallax path. No warning. About This Report reads `Branding: default Parallax`. |
| `"logo_missing"` | Logo file referenced but rejected or absent on disk | Palette + fonts usable; cover-page / header logo skipped. About This Report reads `Branding: white-label (source: <ref>) (logo unavailable, omitted)`. |
| `"schema_invalid"` | Schema validation failed | Fall back to defaults. About This Report reads `Branding: default Parallax (config error)`. |
| `"yaml_parse_error"` / `"yaml_read_error"` / `"config_error"` | YAML corrupt or unreadable | Fall back to defaults. About This Report reads `Branding: default Parallax (config error)`. |
| `"schema_unavailable"` | Loader's own schema file missing, or the `jsonschema` package is not installed | Best-effort branding apply; About This Report reads `Branding: white-label (best-effort, schema unavailable)`. |

The `is_white_label_active()` helper in §2 collapses these to a binary: clean, `logo_missing`, or `schema_unavailable` → render the brand (palette/fonts usable, with best-effort caveat for `schema_unavailable`); anything else → default Parallax. The JSON command also requires a displayable client name or a nonempty color, font or logo value after filtering; otherwise its rendering flag is false.

---

## §5 — Substitution for markdown skills

Markdown skills (the 12 Tier 2 consumers) render in chat, not to .docx. "Branding" reduces to three render-time elements:

1. **Header line** (when `white_label_active` AND `client_name != ""`): one line at the top of the deliverable, **below the House View Preamble if a view is active** (per `_vendored/_parallax/house-view/loader.md` §5.1, the load preamble goes "at the very top"; Branding Header is content-level and follows). Before any analytical content:
   ```
   **<client_name>** report
   ```
   If `client_name == ""` (legacy config with no name field), **skip the header line entirely** — do not render `**** report` with empty bolding. The deliverable starts with the first analytical section in that case.

   If `branding["logos"]["primary"]` is set AND is a URL (starts with `http://` or `https://`), embed: `![<client_name>](<url>)`. **The logo MUST render on its OWN line immediately ABOVE the branding text line** to ensure the shared render gate preserves it (see `parallax-conventions.md` §10). The loader resolves on-disk logos to absolute local filesystem paths (e.g., `/Users/<user>/.parallax/client-branding/primary-logo.png`), which are not embeddable in any markdown delivered over a network. **If `branding["logos"]["primary"]` starts with `/` or `~`, skip image embed entirely and add a second About This Report line: `Logo on file: <basename>`** (see §7).

2. **About This Report footer** (always present when this skill is wired, regardless of `white_label_active`): see §7.

3. **No palette tokens.** Markdown rendered in chat has no color-token substrate, so palette swap is degenerate. The semantic-token rule (§1) still applies but is moot for markdown skills — they have no `cg-green-700` references to begin with. **Implication for `error == "logo_missing"`:** for markdown skills, `logo_missing` has no effect on rendering beyond the About This Report line — there is no palette or font substitution to apply or skip. The skill renders normally with the client_name header (if any) and the `logo_missing` About This Report line.

Markdown skills do NOT modify their analytical content based on `white_label_active`. Branding is a presentation overlay, not a synthesis flag.

---

## §6 — Substitution for docx skills

The single docx consumer in this PR is `cio-letter-prep` (post-retrofit). When `white_label_active`, the renderer substitutes brand-identity tokens with the client's config and leaves semantic tokens (positive / negative / warning) untouched. This table is the canonical reference; cio-letter-prep/SKILL.md applies it.

| Default token | Substitute with | Notes |
|---|---|---|
| `cg-navy-900` | `branding["colors"]["primary"]` | H1/H2 fill, table header fill |
| `cg-navy-700` | `branding["colors"]["secondary"]` (or primary if secondary missing) | H3/H4 |
| `cg-neutral-900` | `branding["colors"]["text"]` | Body text |
| `cg-neutral-100` | derive lighter shade from `branding["colors"]["background"]` | Alternating-row shading; if background is `#FFFFFF`, keep default `#EAEDF3` |
| (no token; new) | `branding["logos"]["primary"]` | Inserted as cover-page header image (left-aligned, ≤ 1.5 inch height). Per §4: skip on `logo_missing`. |
| (no token; new) | `branding["fonts"]["header"]` | Word style: Heading 1, Heading 2, Heading 3 |
| (no token; new) | `branding["fonts"]["body"]` | Word style: Body Text, table cells |
| `cg-green-700` | **(unchanged)** | Semantic positive — never branded |
| `cg-red-700` | **(unchanged)** | Semantic negative — never branded |
| `cg-amber-700` / `cg-amber-50` | **(unchanged)** | Semantic warning — never branded |
| `cg-neutral-500` | **(unchanged)** | Muted text contrast — fund's `text` color may be too dark for muting |

Cover-page client name: when `white_label_active` AND `client_name != ""`, the docx cover-page header gains the client name in the brand `branding["fonts"]["header"]` style at H1. When `client_name == ""`, omit the client name from the cover; the cover-page logo (if present) still renders.

**Per-skill exception — voice handling:** cio-letter-prep is the one wired skill that COULD legitimately be argued to use `branding["voice"]` (it generates CIO-authored prose). Per the cio-letter-prep gotchas, voice is OUT of scope for this skill regardless: the CIO writes the prose; the loader's voice config is ignored. The fact that cio-letter-prep uses `load_visual_branding()` (not `load_client_branding()`) is the structural enforcement of this rule — the wrapper does not expose voice.

Future writing-pipeline skills (newsletter, content) that DO want voice will call `load_client_branding()` directly and document their voice handling in their own SKILL.md. They are out of scope for this integration pattern.

---

## §7 — About This Report footer line template

Every wired skill renders a Branding line in its About This Report footer. The line is unconditional — it appears whether or not `white_label_active`. Pick the row from the §2 command's `error` class; when `white_label_active` is false, use a default-Parallax row whatever the class. Format:

In every row below, `<ref>` is the §2 command's `source_reference` (`safe_source_reference(branding)` from `loader.py`) — URLs collapse to `scheme://hostname`, protocol-relative URLs to `//hostname`, filesystem paths to basename. Never embed `branding["source"]["reference"]` directly; pre-signed URLs and internal paths must not reach end-client output. Scheme references without `://` are omitted rather than displayed as labels; Windows drive paths remain local paths. Explicit local paths retain literal `#` and `?` in their basenames; bare filenames still have query/fragment suffixes removed, including any separators inside those suffixes. A redacted reference over 256 characters is omitted, including a joined multi-source reference.

| Condition | Markdown skills | Docx skills (cio-letter-prep) |
|---|---|---|
| Clean load | `Branding: white-label (source: <ref>)` | same |
| `logo_missing` | `Branding: white-label (source: <ref>) (logo unavailable, omitted)` | `Branding: white-label (source: <ref>) (logo unavailable, omitted from cover)` |
| `config_not_found` | `Branding: default Parallax` | same |
| `schema_invalid` / `yaml_parse_error` / `yaml_read_error` / `config_error`, or the §2 command failed | `Branding: default Parallax (config error)` | same |
| `schema_unavailable`, or `schema_unavailable; logo_missing` | `Branding: white-label (best-effort, schema unavailable)` | same |
| Host has no shell (§2) | `Branding: default Parallax (not loaded: no shell)` | same |
| Markdown skill, abs-local logo skipped per §5 | Append `Logo on file: <basename>` as a second About This Report line | N/A (docx embeds the logo directly) |
| Resolved audience is `client_safe` | Append `Audience mode: client-safe` per `parallax-conventions.md` §13.4 | same |

The docx `from cover` qualifier is more precise (the logo is specifically the cover-page header asset). Markdown skills have no cover; the unqualified `omitted` is correct for them.

For markdown skills the About This Report footer is the last block of the deliverable. For docx (cio-letter-prep) the About This Report footer is rendered in the small-italic style per cio-letter-prep/SKILL.md About This Report section.

**Currency basis (unconditional second line).** Every wired skill also renders a second About This Report line, independent of `white_label_active` and independent of the Branding-line condition above:

```
Currency: figures as reported by source data; no base-currency conversion applied.
```

Use exactly this wording — it states the absence of conversion, not a currency guarantee. Rollout starts with the monitoring and ranking skills and completes library-wide in a later render-mode pass.

---

## §8 — Gotchas

1. **Do not re-parse the config file.** `loader.py` already does `yaml.safe_load` with proper error handling; a second `yaml.safe_load` in a consumer skill bypasses that.
2. **Tolerate empty `client_name`.** Legacy configs predating the field return `""`. Header line in §5 simply omits the name in that case; do not error.
3. **Markdown logo path is environment-dependent.** Loader returns absolute local paths. Per §5 resolution: skip image embed for any path starting with `/` or `~`; add the About This Report "Logo on file" line instead.
4. **Voice is structurally inaccessible.** `branding["voice"]` raises `KeyError` (not `None`). Do not write defensive code like `branding.get("voice", {})` — that re-introduces the model-obedience-only guardrail this wrapper exists to remove. If a skill needs voice, it must explicitly call `load_client_branding()` (full loader) and document why.
5. **Semantic tokens are never overridden.** `cg-green-700`, `cg-red-700`, `cg-amber-*` carry meaning, not brand identity. Even when `white_label_active`, these remain unchanged. (Markdown skills have no color tokens to override; this rule applies to docx skills.)
6. **`white_label_active` is binary, not three-valued.** Clean, `logo_missing` and `schema_unavailable` states permit branding; every other class is default Parallax. The JSON command also requires renderable filtered content. Use its flag directly; Python callers use `loader.visual_branding_summary()` for the same filtered result.

---

## §9 — Versioning

Loader return shape is the contract surface. If `load_visual_branding()` grows a new key (e.g., `icons`), update `_VISUAL_BRANDING_KEYS` in loader.py AND this doc's §3 in the same commit. This version adds the `render` key alongside the `_VISUAL_BRANDING_KEYS` update so deployment render defaults can flow to `parallax-conventions.md` §13 consumers. If a new error class is added to the loader, update §4 in the same commit.

The `tests/test_loader.py::test_visual_branding_keys_are_subset_of_load_client_branding` test is the structural drift gate for the constant.
